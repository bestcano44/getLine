"""SQLite API for Paper Loop, a small peer-to-peer book exchange."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import base64
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import os

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "book_exchange.sqlite3"
DB_PATH.parent.mkdir(exist_ok=True)


def connect():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    db.execute("PRAGMA busy_timeout = 10000")
    return db


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    hashed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
    return salt.hex() + "$" + hashed.hex()


def verify_password(password, stored):
    try:
        salt_hex, _ = stored.split("$", 1)
        return hmac.compare_digest(hash_password(password, bytes.fromhex(salt_hex)), stored)
    except (ValueError, AttributeError):
        return False


def ensure_demo_seller(db):
    demo = db.execute("SELECT id FROM users WHERE email='demo@paperloop.local'").fetchone()
    if demo:
        return demo["id"]
    cur = db.execute("INSERT INTO users(display_name,email,password_hash) VALUES (?,?,?)",
                     ("Paper Loop Seller", "demo@paperloop.local", hash_password("PaperLoop2026!")))
    return cur.lastrowid


def has_column(db, table, column):
    return column in {row[1] for row in db.execute(f"PRAGMA table_info({table})")}


def migrate(db):
    additions = {
        "books": {
            "barcode": "TEXT NOT NULL DEFAULT ''",
            "seller_user_id": "INTEGER REFERENCES users(id) ON DELETE SET NULL",
            "status": "TEXT NOT NULL DEFAULT 'active'",
            "image_data": "TEXT NOT NULL DEFAULT ''",
        },
        "transactions": {
            "seller_user_id": "INTEGER REFERENCES users(id) ON DELETE SET NULL",
            "offered_book_id": "INTEGER REFERENCES books(id) ON DELETE SET NULL",
            "offered_image": "TEXT NOT NULL DEFAULT ''",
            "fulfillment": "TEXT NOT NULL DEFAULT 'shipping'",
            "recipient_name": "TEXT NOT NULL DEFAULT ''",
            "phone": "TEXT NOT NULL DEFAULT ''",
            "address": "TEXT NOT NULL DEFAULT ''",
            "tracking_company": "TEXT NOT NULL DEFAULT ''",
            "tracking_number": "TEXT NOT NULL DEFAULT ''",
            "updated_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
    }
    for table, columns in additions.items():
        for column, definition in columns.items():
            if not has_column(db, table, column):
                db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
    if not has_column(db, "transactions", "seller_user_id"):
        return
    db.execute("""CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
        sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        body TEXT NOT NULL CHECK(length(body) BETWEEN 1 AND 2000),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    db.execute("CREATE INDEX IF NOT EXISTS messages_thread_idx ON messages(transaction_id,id)")
    db.execute("CREATE INDEX IF NOT EXISTS books_barcode_idx ON books(barcode)")
    db.execute("CREATE INDEX IF NOT EXISTS transactions_buyer_idx ON transactions(user_id,id)")
    db.execute("CREATE INDEX IF NOT EXISTS transactions_seller_idx ON transactions(seller_user_id,id)")
    demo_id = ensure_demo_seller(db)
    db.execute("""UPDATE books SET seller_user_id=?,seller='Paper Loop Seller'
        WHERE seller_user_id IS NULL AND id BETWEEN 1 AND 8""", (demo_id,))
    # Earlier app versions only stored the buyer and could not route seller requests.
    db.execute("""UPDATE transactions SET seller_user_id=(
        SELECT seller_user_id FROM books WHERE books.id=transactions.book_id
    ) WHERE seller_user_id IS NULL AND book_id IS NOT NULL""")
    db.commit()


def initialize():
    with connect() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                display_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                subtitle TEXT DEFAULT '',
                author TEXT NOT NULL,
                category TEXT NOT NULL,
                barcode TEXT NOT NULL DEFAULT '',
                price REAL NOT NULL DEFAULT 0,
                mode TEXT NOT NULL CHECK(mode IN ('both','sale','exchange')),
                wanted_books TEXT NOT NULL DEFAULT '[]',
                condition TEXT NOT NULL,
                seller TEXT NOT NULL,
                seller_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                location TEXT NOT NULL DEFAULT 'Local pickup',
                color TEXT NOT NULL DEFAULT 'sage',
                mark TEXT NOT NULL DEFAULT '',
                likes INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'active',
                image_data TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS favorites (
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id,book_id)
            );
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
                user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                title TEXT NOT NULL,
                seller TEXT NOT NULL,
                status TEXT NOT NULL,
                my_book TEXT,
                message TEXT,
                offer_price REAL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                seller_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                offered_book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
                offered_image TEXT NOT NULL DEFAULT '',
                fulfillment TEXT NOT NULL DEFAULT 'shipping',
                recipient_name TEXT NOT NULL DEFAULT '',
                phone TEXT NOT NULL DEFAULT '',
                address TEXT NOT NULL DEFAULT '',
                tracking_company TEXT NOT NULL DEFAULT '',
                tracking_number TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
                sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                body TEXT NOT NULL CHECK(length(body) BETWEEN 1 AND 2000),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        """)
        migrate(db)


def user_json(user):
    return {"id": user["id"], "displayName": user["display_name"], "email": user["email"]}


def book_json(row):
    item = dict(row)
    item["wantedBooks"] = json.loads(item.pop("wanted_books"))
    item["image"] = item.pop("image_data", "")
    item.pop("created_at", None)
    return item


def transaction_json(db, row, viewer_id):
    item = dict(row)
    book = db.execute("SELECT price,barcode FROM books WHERE id=?", (row["book_id"],)).fetchone() if row["book_id"] else None
    item["price"] = book["price"] if book else (item["offer_price"] or 0)
    item["barcode"] = book["barcode"] if book else ""
    item["isBuyer"] = item["user_id"] == viewer_id
    item["isSeller"] = item["seller_user_id"] == viewer_id
    item["myBook"] = item.pop("my_book")
    item["offerPrice"] = item.pop("offer_price")
    item["bookId"] = item.pop("book_id")
    item["offeredBookId"] = item.pop("offered_book_id")
    item["offeredImage"] = item.pop("offered_image")
    item["buyerId"] = item.pop("user_id")
    item["sellerId"] = item.pop("seller_user_id")
    item["recipientName"] = item.pop("recipient_name")
    item["trackingCompany"] = item.pop("tracking_company")
    item["trackingNumber"] = item.pop("tracking_number")
    item["createdAt"] = item.pop("created_at")
    item["updatedAt"] = item.pop("updated_at")
    item["messages"] = [dict(message) for message in db.execute(
        """SELECT messages.id,messages.sender_id AS senderId,users.display_name AS sender,
                  messages.body,messages.created_at AS createdAt
           FROM messages JOIN users ON users.id=messages.sender_id
           WHERE transaction_id=? ORDER BY messages.id""", (row["id"],))]
    return item


class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, value):
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS")
        self.end_headers()
        self.wfile.write(body)

    def body_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > 3_000_000:
            raise ValueError("Request is too large")
        return json.loads(self.rfile.read(length) or b"{}")

    def current_user(self, db):
        auth = self.headers.get("Authorization", "")
        token = auth[7:] if auth.startswith("Bearer ") else ""
        if not token:
            return None
        return db.execute("""SELECT users.id,users.display_name,users.email
            FROM sessions JOIN users ON users.id=sessions.user_id
            WHERE sessions.token=? AND sessions.created_at > datetime('now','-30 days')""", (token,)).fetchone()

    def require_user(self, db):
        user = self.current_user(db)
        if not user:
            self.send_json(401, {"error": "Please sign in first"})
        return user

    def do_OPTIONS(self):
        self.send_json(200, {})

    def do_GET(self):
        path = urlparse(self.path).path
        with connect() as db:
            if path == "/api/bootstrap":
                user = self.current_user(db)
                books = [book_json(row) for row in db.execute("SELECT * FROM books ORDER BY id DESC")]
                favorites, transactions = [], []
                if user:
                    favorites = [row[0] for row in db.execute("SELECT book_id FROM favorites WHERE user_id=?", (user["id"],))]
                    rows = db.execute("""SELECT t.*, buyer.display_name AS buyerName,
                        seller.display_name AS sellerName FROM transactions t
                        LEFT JOIN users buyer ON buyer.id=t.user_id
                        LEFT JOIN users seller ON seller.id=t.seller_user_id
                        WHERE t.user_id=? OR t.seller_user_id=? ORDER BY t.updated_at DESC,t.id DESC""",
                        (user["id"], user["id"])).fetchall()
                    transactions = [transaction_json(db, row, user["id"]) for row in rows]
                return self.send_json(200, {"books": books, "favorites": favorites,
                    "transactions": transactions, "requests": transactions,
                    "user": user_json(user) if user else None})
        self.send_json(404, {"error": "Not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            body = self.body_json()
        except (ValueError, json.JSONDecodeError) as error:
            return self.send_json(400, {"error": str(error) or "Invalid request"})
        with connect() as db:
            if path == "/api/auth/register":
                name = str(body.get("displayName", "")).strip()
                email = str(body.get("email", "")).strip().lower()
                password = str(body.get("password", ""))
                if not 2 <= len(name) <= 40:
                    return self.send_json(400, {"error": "Name must be 2 to 40 characters"})
                if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
                    return self.send_json(400, {"error": "Enter a valid email address"})
                if len(password) < 8 or len(password) > 200:
                    return self.send_json(400, {"error": "Password must be at least 8 characters"})
                try:
                    cur = db.execute("INSERT INTO users(display_name,email,password_hash) VALUES (?,?,?)",
                                     (name, email, hash_password(password)))
                except sqlite3.IntegrityError:
                    return self.send_json(409, {"error": "An account with this email already exists"})
                user = db.execute("SELECT id,display_name,email FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
                token = secrets.token_urlsafe(32)
                db.execute("INSERT INTO sessions(token,user_id) VALUES (?,?)", (token, user["id"]))
                db.commit()
                return self.send_json(201, {"token": token, "user": user_json(user)})

            if path == "/api/auth/login":
                email = str(body.get("email", "")).strip().lower()
                record = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
                if not record or not verify_password(str(body.get("password", "")), record["password_hash"]):
                    return self.send_json(401, {"error": "Incorrect email or password"})
                user = db.execute("SELECT id,display_name,email FROM users WHERE id=?", (record["id"],)).fetchone()
                token = secrets.token_urlsafe(32)
                db.execute("INSERT INTO sessions(token,user_id) VALUES (?,?)", (token, user["id"]))
                db.commit()
                return self.send_json(200, {"token": token, "user": user_json(user)})

            if path == "/api/seed":
                if db.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0:
                    demo_id = ensure_demo_seller(db)
                    for book in body.get("books", []):
                        db.execute("""INSERT INTO books
                            (id,title,subtitle,author,category,barcode,price,mode,wanted_books,condition,seller,seller_user_id,location,color,mark,likes)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (book["id"],book["title"],book.get("subtitle",""),book["author"],book["category"],book.get("barcode",""),
                             book["price"],book["mode"],json.dumps(book.get("wantedBooks",[])),book["condition"],"Paper Loop Seller",demo_id,
                             book["location"],book.get("color","sage"),book.get("mark",""),book.get("likes",0)))
                return self.send_json(200, {"ok": True})

            user = self.require_user(db)
            if not user:
                return
            if path == "/api/books":
                required = ("title", "author", "category", "mode", "condition", "barcode")
                if any(not str(body.get(key, "")).strip() for key in required):
                    return self.send_json(400, {"error": "Complete all required book fields"})
                barcode = "".join(char for char in str(body["barcode"]) if char.isdigit())
                if len(barcode) not in (10, 13):
                    return self.send_json(400, {"error": "Enter a 10 or 13 digit ISBN barcode"})
                mode = body["mode"]
                if mode not in ("both", "sale", "exchange"):
                    return self.send_json(400, {"error": "Choose a valid trade option"})
                try:
                    price = float(body.get("price") or 0)
                except (ValueError, TypeError):
                    return self.send_json(400, {"error": "Enter a valid price"})
                if (mode != "exchange" and price <= 0) or price > 1_000_000:
                    return self.send_json(400, {"error": "Enter a valid price"})
                wanted = [str(title).strip() for title in body.get("wantedBooks", []) if str(title).strip()]
                image = str(body.get("image", ""))
                if image and (not image.startswith("data:image/") or len(image) > 1_500_000):
                    return self.send_json(400, {"error": "Choose an image smaller than 1 MB"})
                cur = db.execute("""INSERT INTO books
                    (title,subtitle,author,category,barcode,price,mode,wanted_books,condition,seller,seller_user_id,location,color,mark,likes,image_data)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?)""", (str(body["title"]).strip()[:120],str(body.get("subtitle", "")).strip()[:160],
                     str(body["author"]).strip()[:100],str(body["category"]).strip()[:60],barcode,price,mode,
                     json.dumps(wanted),str(body["condition"]).strip(),user["display_name"],user["id"],
                     str(body.get("location", "Local pickup")).strip()[:120] or "Local pickup",
                     str(body.get("color", "sage")),str(body["title"]).strip()[:1],image))
                return self.send_json(201, book_json(db.execute("SELECT * FROM books WHERE id=?", (cur.lastrowid,)).fetchone()))

            if path == "/api/favorites":
                book_id = int(body.get("bookId", 0))
                if not db.execute("SELECT 1 FROM books WHERE id=?", (book_id,)).fetchone():
                    return self.send_json(404, {"error": "Book not found"})
                found = db.execute("SELECT 1 FROM favorites WHERE user_id=? AND book_id=?", (user["id"], book_id)).fetchone()
                if found:
                    db.execute("DELETE FROM favorites WHERE user_id=? AND book_id=?", (user["id"], book_id))
                    return self.send_json(200, {"bookId": book_id, "favorite": False})
                db.execute("INSERT INTO favorites(user_id,book_id) VALUES (?,?)", (user["id"], book_id))
                return self.send_json(201, {"bookId": book_id, "favorite": True})

            if path == "/api/transactions":
                book_id = int(body.get("bookId", 0))
                book = db.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
                if not book or book["status"] != "active":
                    return self.send_json(409, {"error": "This book is no longer available"})
                if book["seller_user_id"] == user["id"]:
                    return self.send_json(400, {"error": "You cannot start a transaction for your own listing"})
                kind = body.get("type")
                if kind not in ("Purchase", "Exchange", "Message"):
                    return self.send_json(400, {"error": "Choose a valid request type"})
                if kind == "Purchase" and book["mode"] == "exchange":
                    return self.send_json(400, {"error": "This listing is available for exchange only"})
                if kind == "Exchange":
                    if book["mode"] == "sale":
                        return self.send_json(400, {"error": "This listing is for sale only"})
                    offered_image = str(body.get("offeredImage", ""))
                    if not offered_image.startswith("data:image/") or len(offered_image) > 1_500_000:
                        return self.send_json(400, {"error": "Upload a clear photo of the book you are offering (under 1 MB)"})
                else:
                    offered_image = ""
                if kind == "Purchase":
                    required = ["recipientName", "phone"]
                    if body.get("fulfillment") == "shipping":
                        required.append("address")
                    if any(not str(body.get(key, "")).strip() for key in required):
                        return self.send_json(400, {"error": "Complete the delivery details"})
                status = "Awaiting seller response"
                if kind in ("Purchase", "Exchange"):
                    # A single active deal can reserve this listing at a time.
                    open_deal = db.execute("""SELECT 1 FROM transactions WHERE book_id=?
                        AND (type IN ('Purchase','Exchange') OR (type='Message' AND offer_price IS NOT NULL))
                        AND status NOT IN ('Declined','Cancelled','Completed')""",
                                           (book_id,)).fetchone()
                    if open_deal:
                        return self.send_json(409, {"error": "Another buyer has an active request for this book"})
                offer = body.get("offerPrice")
                if offer is not None:
                    offer = float(offer)
                    if offer <= 0 or offer > 1_000_000:
                        return self.send_json(400, {"error": "Enter a valid offer amount"})
                cur = db.execute("""INSERT INTO transactions
                    (type,book_id,user_id,title,seller,status,my_book,message,offer_price,seller_user_id,offered_book_id,offered_image,
                     fulfillment,recipient_name,phone,address)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (kind,book_id,user["id"],book["title"],book["seller"],status,
                     body.get("myBook"),str(body.get("message", "")).strip() or None,offer,
                     book["seller_user_id"],None,offered_image,
                     body.get("fulfillment", "pickup" if kind == "Exchange" else "shipping"),
                     str(body.get("recipientName", "")).strip(),str(body.get("phone", "")).strip(),
                     str(body.get("address", "")).strip()))
                if body.get("message"):
                    db.execute("INSERT INTO messages(transaction_id,sender_id,body) VALUES (?,?,?)",
                               (cur.lastrowid,user["id"],str(body["message"]).strip()[:2000]))
                db.commit()
                return self.send_json(201, {"id": cur.lastrowid})

            if path == "/api/messages":
                transaction_id = int(body.get("transactionId", 0))
                transaction = db.execute("SELECT * FROM transactions WHERE id=?", (transaction_id,)).fetchone()
                if not transaction or user["id"] not in (transaction["user_id"], transaction["seller_user_id"]):
                    return self.send_json(404, {"error": "Conversation not found"})
                message = str(body.get("body", "")).strip()
                if not message or len(message) > 2000:
                    return self.send_json(400, {"error": "Message must be 1 to 2000 characters"})
                db.execute("INSERT INTO messages(transaction_id,sender_id,body) VALUES (?,?,?)",
                           (transaction_id,user["id"],message))
                db.execute("UPDATE transactions SET updated_at=CURRENT_TIMESTAMP WHERE id=?", (transaction_id,))
                return self.send_json(201, {"ok": True})

        self.send_json(404, {"error": "Not found"})

    def do_PATCH(self):
        match = re.fullmatch(r"/api/(transactions|books)/(\d+)", urlparse(self.path).path)
        if not match:
            return self.send_json(404, {"error": "Not found"})
        resource, resource_id = match.group(1), int(match.group(2))
        try:
            body = self.body_json()
        except (ValueError, json.JSONDecodeError) as error:
            return self.send_json(400, {"error": str(error) or "Invalid request"})
        with connect() as db:
            user = self.require_user(db)
            if not user:
                return
            if resource == "books":
                book = db.execute("SELECT * FROM books WHERE id=? AND seller_user_id=?", (resource_id,user["id"])).fetchone()
                if not book:
                    return self.send_json(404, {"error": "Listing not found"})
                if body.get("action") == "edit":
                    active = db.execute("SELECT 1 FROM transactions WHERE book_id=? AND status NOT IN ('Declined','Cancelled','Completed')", (resource_id,)).fetchone()
                    if active:
                        return self.send_json(409, {"error": "This listing cannot be edited while a transaction is active"})
                    required = ("title", "author", "category", "barcode", "mode", "condition")
                    if any(not str(body.get(key, "")).strip() for key in required):
                        return self.send_json(400, {"error": "Complete all required book fields"})
                    barcode = "".join(char for char in str(body["barcode"]) if char.isdigit())
                    mode = body["mode"]
                    wanted = [str(title).strip() for title in body.get("wantedBooks", []) if str(title).strip()]
                    try:
                        price = float(body.get("price") or 0)
                    except (ValueError, TypeError):
                        return self.send_json(400, {"error": "Enter a valid price"})
                    image = str(body.get("image", ""))
                    if len(barcode) not in (10,13) or mode not in ("both","sale","exchange"):
                        return self.send_json(400, {"error": "Enter a valid ISBN and trade option"})
                    if (mode != "exchange" and price <= 0) or price > 1_000_000:
                        return self.send_json(400, {"error": "Enter a valid price"})
                    if image and (not image.startswith("data:image/") or len(image) > 1_500_000):
                        return self.send_json(400, {"error": "Choose an image smaller than 1 MB"})
                    db.execute("""UPDATE books SET title=?,author=?,category=?,barcode=?,price=?,mode=?,
                        wanted_books=?,condition=?,image_data=?,mark=?,subtitle=? WHERE id=?""",
                        (str(body["title"]).strip()[:120],str(body["author"]).strip()[:100],
                         str(body["category"]).strip()[:60],barcode,price,mode,json.dumps(wanted),
                         str(body["condition"]).strip(),image,str(body["title"]).strip()[:1],
                         str(body.get("subtitle", "")).strip()[:160],resource_id))
                    return self.send_json(200, book_json(db.execute("SELECT * FROM books WHERE id=?", (resource_id,)).fetchone()))
                if "status" in body:
                    if body["status"] not in ("active", "paused"):
                        return self.send_json(400, {"error": "Invalid listing state"})
                    if body["status"] == "paused":
                        active = db.execute("SELECT 1 FROM transactions WHERE book_id=? AND status NOT IN ('Declined','Cancelled','Completed')",
                                            (resource_id,)).fetchone()
                        if active:
                            return self.send_json(409, {"error": "This listing has an active buyer request and cannot be paused"})
                    db.execute("UPDATE books SET status=? WHERE id=?", (body["status"],resource_id))
                return self.send_json(200, {"ok": True})
            transaction = db.execute("SELECT * FROM transactions WHERE id=?", (resource_id,)).fetchone()
            if not transaction or user["id"] not in (transaction["user_id"], transaction["seller_user_id"]):
                return self.send_json(404, {"error": "Transaction not found"})
            action = body.get("action")
            is_seller = transaction["seller_user_id"] == user["id"]
            status = transaction["status"]
            if action in ("accept", "decline"):
                if not is_seller or status != "Awaiting seller response":
                    return self.send_json(409, {"error": "This request can no longer be answered"})
                if action == "decline":
                    db.execute("UPDATE transactions SET status='Declined',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
                elif transaction["type"] == "Purchase":
                    db.execute("UPDATE transactions SET status='Awaiting payment',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
                elif transaction["type"] == "Exchange":
                    listing = db.execute("UPDATE books SET status='reserved' WHERE id=? AND status='active'", (transaction["book_id"],))
                    if listing.rowcount != 1:
                        db.rollback()
                        return self.send_json(409, {"error": "The listed book is no longer available for this exchange"})
                    if transaction["offered_book_id"]:
                        offered = db.execute("UPDATE books SET status='reserved' WHERE id=? AND seller_user_id=? AND status='active'",
                                             (transaction["offered_book_id"],transaction["user_id"]))
                        if offered.rowcount != 1:
                            db.rollback()
                            return self.send_json(409, {"error": "The buyer's offered listing is no longer available"})
                    db.execute("UPDATE transactions SET status='Accepted · arrange exchange',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
                elif transaction["type"] == "Message" and transaction["offer_price"]:
                    db.execute("UPDATE transactions SET type='Purchase',status='Awaiting delivery details',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
                else:
                    db.execute("UPDATE transactions SET status='In conversation',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
            elif action == "details":
                if is_seller or transaction["type"] != "Purchase" or status != "Awaiting delivery details":
                    return self.send_json(409, {"error": "This order is not waiting for delivery details"})
                fulfillment = body.get("fulfillment", "shipping")
                if fulfillment not in ("shipping", "pickup"):
                    return self.send_json(400, {"error": "Choose shipping or local pickup"})
                name, phone, address = (str(body.get(key, "")).strip() for key in ("recipientName", "phone", "address"))
                if not name or not phone or (fulfillment == "shipping" and not address):
                    return self.send_json(400, {"error": "Complete the delivery details"})
                db.execute("""UPDATE transactions SET fulfillment=?,recipient_name=?,phone=?,address=?,
                    status='Awaiting payment',updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (fulfillment,name[:100],phone[:50],address[:500],resource_id))
            elif action == "pay":
                if is_seller or transaction["type"] != "Purchase" or status != "Awaiting payment":
                    return self.send_json(409, {"error": "This order is not ready for payment"})
                reserved = db.execute("UPDATE books SET status='reserved' WHERE id=? AND status='active'", (transaction["book_id"],))
                if reserved.rowcount != 1:
                    return self.send_json(409, {"error": "This listing is no longer available"})
                db.execute("UPDATE transactions SET status='Paid · preparing shipment',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
            elif action == "fulfill":
                if not is_seller or status not in ("Paid · preparing shipment", "Accepted · arrange exchange"):
                    return self.send_json(409, {"error": "This transaction is not ready for handover"})
                company = str(body.get("trackingCompany", "")).strip()[:80]
                tracking = str(body.get("trackingNumber", "")).strip()[:120]
                if transaction["fulfillment"] == "shipping" and (not company or not tracking):
                    return self.send_json(400, {"error": "Enter the courier and tracking number"})
                new_status = "Shipped" if transaction["fulfillment"] == "shipping" else "Ready for collection"
                db.execute("""UPDATE transactions SET status=?,tracking_company=?,tracking_number=?,
                    updated_at=CURRENT_TIMESTAMP WHERE id=?""", (new_status,company,tracking,resource_id))
            elif action == "received":
                if is_seller or status not in ("Shipped", "Ready for collection"):
                    return self.send_json(409, {"error": "This transaction is not awaiting your confirmation"})
                db.execute("UPDATE transactions SET status='Completed',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
                if transaction["type"] in ("Purchase", "Exchange"):
                    db.execute("UPDATE books SET status='sold' WHERE id=?", (transaction["book_id"],))
                    if transaction["type"] == "Exchange" and transaction["offered_book_id"]:
                        db.execute("UPDATE books SET status='sold' WHERE id=? AND status='reserved'", (transaction["offered_book_id"],))
            elif action == "cancel":
                if is_seller or status not in ("Awaiting seller response", "Awaiting payment", "Awaiting delivery details", "Paid · preparing shipment", "Accepted · arrange exchange"):
                    return self.send_json(409, {"error": "This transaction can no longer be cancelled"})
                db.execute("UPDATE transactions SET status='Cancelled',updated_at=CURRENT_TIMESTAMP WHERE id=?", (resource_id,))
                if transaction["type"] == "Purchase":
                    db.execute("UPDATE books SET status='active' WHERE id=? AND status='reserved'", (transaction["book_id"],))
                elif transaction["type"] == "Exchange":
                    db.execute("UPDATE books SET status='active' WHERE id=? AND status='reserved'", (transaction["book_id"],))
                    if transaction["offered_book_id"]:
                        db.execute("UPDATE books SET status='active' WHERE id=? AND status='reserved'", (transaction["offered_book_id"],))
            else:
                return self.send_json(400, {"error": "Unknown transaction action"})
            db.commit()
            return self.send_json(200, {"ok": True})

    def do_DELETE(self):
        path = urlparse(self.path).path
        token = self.headers.get("Authorization", "")
        token = token[7:] if token.startswith("Bearer ") else ""
        with connect() as db:
            if path == "/api/auth/session":
                db.execute("DELETE FROM sessions WHERE token=?", (token,))
                return self.send_json(200, {"ok": True})
            match = re.fullmatch(r"/api/books/(\d+)", path)
            if match:
                user = self.require_user(db)
                if not user:
                    return
                book_id = int(match.group(1))
                has_deal = db.execute("SELECT 1 FROM transactions WHERE book_id=? AND status NOT IN ('Declined','Cancelled','Completed')", (book_id,)).fetchone()
                cur = db.execute("DELETE FROM books WHERE id=? AND seller_user_id=? AND status IN ('active','paused')",
                                 (book_id,user["id"])) if not has_deal else None
                if not cur or cur.rowcount == 0:
                    return self.send_json(409, {"error": "This listing cannot be removed while a transaction is active"})
                return self.send_json(200, {"ok": True})
        self.send_json(404, {"error": "Not found"})

    def log_message(self, fmt, *args):
        print("[paper-loop-api]", fmt % args)


initialize()
print(f"SQLite database: {DB_PATH}")
ThreadingHTTPServer(("127.0.0.1", int(os.environ.get("PAPER_LOOP_PORT", "8002"))), Handler).serve_forever()

import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { startPythonServer } from "./python-server.mjs";

const viteFile = fileURLToPath(new URL("../node_modules/vite/bin/vite.js", import.meta.url));
const [nodeMajor, nodeMinor] = process.versions.node.split(".").map(Number);
const supportedNode = (nodeMajor === 20 && nodeMinor >= 19) || (nodeMajor === 22 && nodeMinor >= 12) || nodeMajor > 22;
if (!supportedNode) {
  console.error(`This project requires Node.js 20.19+ or 22.12+. Current version: ${process.version}`);
  process.exit(1);
}
let backend;
let vite;
let stopping = false;

function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  backend?.kill();
  vite?.kill();
  process.exitCode = code;
}

process.once("SIGINT", () => stop(130));
process.once("SIGTERM", () => stop(0));

try {
  backend = await startPythonServer();
  backend.on("error", (error) => {
    console.error("Database service error:", error.message);
    stop(1);
  });
  backend.on("exit", (code) => {
    if (!stopping) {
      console.error("Database service stopped.");
      stop(code || 1);
    }
  });

  vite = spawn(process.execPath, [viteFile, "--host", "127.0.0.1"], { stdio: "inherit" });
  vite.on("error", (error) => {
    console.error("Website service error:", error.message);
    stop(1);
  });
  vite.on("exit", (code) => stop(code || 0));
} catch (error) {
  console.error(error.message);
  stop(1);
}

import { startPythonServer } from "./python-server.mjs";

try {
  const server = await startPythonServer();
  process.once("SIGINT", () => server.kill());
  process.once("SIGTERM", () => server.kill());
  server.on("error", (error) => {
    console.error("Database service error:", error.message);
    process.exitCode = 1;
  });
  server.on("exit", (code) => { process.exitCode = code || 0; });
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}

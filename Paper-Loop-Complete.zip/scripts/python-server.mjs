import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const serverFile = fileURLToPath(new URL("../server.py", import.meta.url));
const pythonCommands = process.platform === "win32"
  ? [["py", ["-3", serverFile]], ["python", [serverFile]]]
  : [["python3", [serverFile]], ["python", [serverFile]]];

export function startPythonServer() {
  return new Promise((resolve, reject) => {
    let index = 0;

    function tryNext() {
      if (index >= pythonCommands.length) {
        reject(new Error("Python 3 was not found. Install Python 3, then restart the app."));
        return;
      }

      const [command, args] = pythonCommands[index++];
      const child = spawn(command, args, { stdio: "inherit", windowsHide: false });
      child.once("spawn", () => resolve(child));
      child.once("error", (error) => {
        if (error.code === "ENOENT") tryNext();
        else reject(error);
      });
    }

    tryNext();
  });
}

export const initialBooks = [
  { id: 1, title: "Siddhartha", subtitle: "Siddhartha", author: "Hermann Hesse", category: "Fiction", barcode: "9780062315007", price: 18, mode: "both", wantedBooks: ["The Moon and Sixpence"], condition: "Very Good", seller: "Mia Chen", location: "Hangzhou · Xihu", color: "sage", mark: "S", likes: 24 },
  { id: 2, title: "Maybe You Should Talk to Someone", subtitle: "Maybe You Should Talk to Someone", author: "Lori Gottlieb", category: "Psychology", barcode: "9781328662057", price: 32, mode: "sale", wantedBooks: [], condition: "Like New", seller: "Olivia Zhao", location: "Shanghai · Xuhui", color: "coral", mark: "M", likes: 18 },
  { id: 3, title: "The Design of Everyday Things", subtitle: "The Design of Everyday Things", author: "Don Norman", category: "Design", barcode: "9780465050659", price: 45, mode: "both", wantedBooks: ["The Little Prince", "Norwegian Wood"], condition: "Good", seller: "Mori Lin", location: "Beijing · Chaoyang", color: "ochre", mark: "D", likes: 31 },
  { id: 4, title: "Sapiens", subtitle: "A Brief History of Humankind", author: "Yuval Noah Harari", category: "History", barcode: "9780062316097", price: 22, mode: "exchange", wantedBooks: ["The Little Prince"], condition: "Good", seller: "Sam Wu", location: "Chengdu · Wuhou", color: "blue", mark: "S", likes: 12 },
  { id: 5, title: "Invisible Cities", subtitle: "Invisible Cities", author: "Italo Calvino", category: "Fiction", barcode: "9780156453806", price: 20, mode: "both", wantedBooks: ["The Moon and Sixpence", "Norwegian Wood"], condition: "Very Good", seller: "Camila Xu", location: "Nanjing · Gulou", color: "lavender", mark: "I", likes: 27 },
  { id: 6, title: "The Art of Photography", subtitle: "The Art of Photography", author: "Bruce Barnbaum", category: "Design", barcode: "9781581153121", price: 56, mode: "sale", wantedBooks: [], condition: "Excellent", seller: "Alex Liu", location: "Guangzhou · Haizhu", color: "sand", mark: "A", likes: 9 },
  { id: 7, title: "Walden", subtitle: "Walden", author: "Henry David Thoreau", category: "Fiction", barcode: "9780140390445", price: 16, mode: "exchange", wantedBooks: ["Norwegian Wood"], condition: "Good", seller: "Ella Sun", location: "Suzhou · Gusu", color: "forest", mark: "W", likes: 15 },
  { id: 8, title: "Peak", subtitle: "Peak: Secrets from the New Science of Expertise", author: "Anders Ericsson", category: "Personal Growth", barcode: "9780544947221", price: 25, mode: "both", wantedBooks: ["The Moon and Sixpence", "The Little Prince"], condition: "Very Good", seller: "Noah Zhang", location: "Wuhan · Hongshan", color: "plum", mark: "P", likes: 21 },
];

export const ownedBooks = [
  { title: "Norwegian Wood", author: "Haruki Murakami" },
  { title: "The Moon and Sixpence", author: "W. Somerset Maugham" },
  { title: "The Little Prince", author: "Antoine de Saint-Exupéry" },
];

export const categories = ["All", "Fiction", "History", "Psychology", "Design", "Personal Growth"];

import React, { useEffect, useMemo, useRef, useState } from "react";
import { categories, initialBooks } from "./data.js";

const navItems = [
  ["home", "Discover", "home"],
  ["categories", "Categories", "grid"],
  ["publish", "List a book", "plus"],
  ["messages", "Activity", "chat"],
  ["profile", "Account", "user"],
];

function Icon({ name, size = 20, stroke = 1.8 }) {
  const paths = {
    home: (
      <>
        <path d="m3 10 9-7 9 7" />
        <path d="M5 9v11h14V9M9 20v-6h6v6" />
      </>
    ),
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1.5" />
        <rect x="14" y="3" width="7" height="7" rx="1.5" />
        <rect x="3" y="14" width="7" height="7" rx="1.5" />
        <rect x="14" y="14" width="7" height="7" rx="1.5" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    chat: (
      <>
        <path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H5l-2 2v-6a7.5 7.5 0 1 1 17-3.5Z" />
        <path d="M8 11h.01M12 11h.01M16 11h.01" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    search: (
      <>
        <circle cx="10.8" cy="10.8" r="6.8" />
        <path d="m16 16 4.5 4.5" />
      </>
    ),
    heart: (
      <path d="M20.8 8.8c0 4.2-8.8 10-8.8 10S3.2 13 3.2 8.8A4.5 4.5 0 0 1 12 6.7a4.5 4.5 0 0 1 8.8 2.1Z" />
    ),
    pin: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    book: (
      <>
        <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z" />
        <path d="M4 5.5v16M8 7h8M8 11h7" />
      </>
    ),
    swap: (
      <>
        <path d="m7 7 3-3 3 3M10 4v12a4 4 0 0 0 4 4h3" />
        <path d="m17 17-3 3 3 3" />
      </>
    ),
    close: (
      <>
        <path d="m6 6 12 12M18 6 6 18" />
      </>
    ),
    arrow: (
      <>
        <path d="M5 12h14M13 6l6 6-6 6" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    sparkle: (
      <>
        <path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z" />
        <path d="m19 15 .9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15Z" />
      </>
    ),
    shield: (
      <>
        <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" />
        <path d="m9 12 2 2 4-4" />
      </>
    ),
    send: (
      <>
        <path d="m22 2-7 20-4-9-9-4Z" />
        <path d="M22 2 11 13" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={stroke}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name] || paths.book}
    </svg>
  );
}

async function apiPost(path, value) {
  const token = window.localStorage.getItem("paper-loop-token");
  const response = await fetch(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(value),
  });
  if (!response.ok) {
    const result = await response.json().catch(() => ({}));
    throw new Error(result.error || `Request failed (${response.status})`);
  }
  return response.json();
}

async function apiPatch(path, value) {
  const token = window.localStorage.getItem("paper-loop-token");
  const response = await fetch(path, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(value),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `Request failed (${response.status})`);
  return result;
}

async function apiDelete(path) {
  const token = window.localStorage.getItem("paper-loop-token");
  const response = await fetch(path, { method: "DELETE", headers: token ? { Authorization: `Bearer ${token}` } : {} });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `Request failed (${response.status})`);
  return result;
}

async function loadBootstrap(token) {
  let lastError;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    try {
      const response = await fetch("/api/bootstrap", {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!response.ok) throw new Error(`Database request failed (${response.status})`);
      return await response.json();
    } catch (error) {
      lastError = error;
      if (attempt < 5) await new Promise((resolve) => window.setTimeout(resolve, 250));
    }
  }
  throw lastError;
}

function BookCover({ book, compact = false }) {
  return (
    <div className={`book-cover cover-${book.color}${compact ? " cover-compact" : ""}${book.image ? " has-photo" : ""}`}>
      {book.image ? <img src={book.image} alt={`${book.title} cover`} /> : <>
      <div className="cover-inner">
        <span className="cover-mark">{book.mark}</span>
        <span className="cover-title">{book.title}</span>
        <span className="cover-author">{book.author}</span>
        <span className="cover-rule" />
        <span className="cover-publisher">Paper Loop · Read again</span>
      </div>
      <span className="cover-spine" />
      </>}
    </div>
  );
}

function BookCard({ book, favorite, isOwner = false, onFavorite, onAction }) {
  const canExchange = !isOwner && book.mode !== "sale";
  const canBuy = !isOwner && book.mode !== "exchange";

  return (
    <article className="book-card">
      <div className="card-cover-wrap">
        <BookCover book={book} />
        <button
          type="button"
          className={`favorite-button${favorite ? " is-favorite" : ""}`}
          aria-label={favorite ? "Remove from saved" : "Save book"}
          onClick={() => onFavorite(book.id)}
        >
          <Icon name="heart" size={17} />
        </button>
        <span
          className={`condition-tag condition-${book.status !== "active" ? "used" : book.condition === "Like New" || book.condition === "Excellent" ? "new" : "used"}`}
        >
          {book.status !== "active" ? book.status : book.condition}
        </span>
      </div>
      <div className="card-body">
        <div className="card-category">{book.category}</div>
        <h3>
          <button
            type="button"
            className="book-detail-trigger"
            onClick={() => onAction(book, "detail")}
          >
            {book.title}
          </button>
        </h3>
        <p className="book-author">{book.author}</p>
        {book.barcode && <p className="book-isbn">ISBN {book.barcode}</p>}
        {book.mode !== "sale" && (
          <p className="wants-line"><Icon name="swap" size={14} /> Open to swaps · photo review</p>
        )}
        <div className="seller-line">
          <span className="seller-avatar">{book.seller.slice(0, 1)}</span>
          <span className="seller-name">{book.seller}</span>
          <span className="seller-location">
            <Icon name="pin" size={12} />
            {book.location.split(" · ")[0]}
          </span>
        </div>
        <div className="card-footer">
          <div className="price-block">
            {canBuy ? (
              <>
                <span className="currency">¥</span>
                <strong>{book.price}</strong>
              </>
            ) : (
              <span className="exchange-only">Swap only</span>
            )}
          </div>
          <div className="card-actions">
            {canExchange && (
              <button
                type="button"
                className="mini-exchange"
                onClick={() => onAction(book, "exchange")}
              >
                Swap
              </button>
            )}
            {canBuy && (
              <button
                type="button"
                className="mini-buy"
                onClick={() => onAction(book, "buy")}
              >
                Buy
              </button>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}

function Modal({ title, subtitle, onClose, children, className = "" }) {
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(event) => event.target === event.currentTarget && onClose()}
    >
      <section
        className={`modal-panel ${className}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="modal-heading">
          <div>
            <h2>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <button
            type="button"
            className="icon-button modal-close"
            onClick={onClose}
            aria-label="Close"
          >
            <Icon name="close" />
          </button>
        </div>
        {children}
      </section>
    </div>
  );
}

function App() {
  const [books, setBooks] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [requests, setRequests] = useState([]);
  const seenTransactions = useRef(new Set());
  const seenMessages = useRef(new Set());
  const [activeNav, setActiveNav] = useState("home");
  const [activeMode, setActiveMode] = useState("all");
  const [activeCategory, setActiveCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState("");
  const [sortBy, setSortBy] = useState("Recommended");
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("paper-loop-user")) || null; }
    catch { return null; }
  });

  useEffect(() => {
    async function loadDatabase() {
      try {
        const token = localStorage.getItem("paper-loop-token");
        let data = await loadBootstrap(token);
        if (data.books.length === 0) {
          await apiPost("/api/seed", { books: initialBooks });
          data = await loadBootstrap(token);
        }
        setBooks(data.books);
        setFavorites(data.favorites);
        setRequests(data.transactions || data.requests || []);
        seenTransactions.current = new Set((data.transactions || data.requests || []).map((item) => item.id));
        seenMessages.current = new Set((data.transactions || data.requests || []).flatMap((item) => (item.messages || []).map((message) => message.id)));
        setUser(data.user || null);
        if (token && !data.user) {
          localStorage.removeItem("paper-loop-token");
          localStorage.removeItem("paper-loop-user");
        }
      } catch {
        showToast("Database unavailable. Start the app with npm run dev.");
      }
    }
    loadDatabase();
  }, []);

  async function refreshData() {
    const data = await loadBootstrap(localStorage.getItem("paper-loop-token"));
    const transactions = data.transactions || data.requests || [];
    const incomingRequest = transactions.some((item) => item.isSeller && item.status === "Awaiting seller response" && !seenTransactions.current.has(item.id));
    const incomingMessage = transactions.some((item) => (item.messages || []).some((message) => message.senderId !== data.user?.id && !seenMessages.current.has(message.id)));
    seenTransactions.current = new Set(transactions.map((item) => item.id));
    seenMessages.current = new Set(transactions.flatMap((item) => (item.messages || []).map((message) => message.id)));
    setBooks(data.books);
    setFavorites(data.favorites);
    setRequests(transactions);
    setUser((current) => current?.id === data.user?.id ? current : data.user || null);
    if (incomingRequest) showToast("New purchase or exchange request received.");
    else if (incomingMessage) showToast("New message received in a transaction.");
  }

  useEffect(() => {
    if (!user) return undefined;
    const timer = window.setInterval(() => refreshData().catch(() => {}), 8000);
    return () => window.clearInterval(timer);
  }, [user?.id]);

  const visibleBooks = useMemo(() => {
    let result = books.filter((book) => {
      const matchesAvailability = activeNav === "profile" || book.status === "active";
      const matchesCategory =
        activeCategory === "All" || book.category === activeCategory;
      const matchesMode =
        activeMode === "all" ||
        book.mode === "both" ||
        book.mode === activeMode;
      const searchText =
        `${book.title} ${book.author} ${book.category} ${(book.wantedBooks || []).join(" ")} ${book.seller} ${book.barcode || ""}`.toLowerCase();
      const digits = query.replace(/\D/g, "");
      const matchesSearch = searchText.includes(query.trim().toLowerCase()) ||
        (digits.length >= 3 && String(book.barcode || "").includes(digits));
      return (
        matchesAvailability &&
        matchesCategory &&
        matchesMode &&
        matchesSearch
      );
    });
    if (sortBy === "Price: Low to High")
      result = [...result].sort((a, b) => a.price - b.price);
    if (sortBy === "Newest") result = [...result].sort((a, b) => b.id - a.id);
    if (activeNav === "profile")
      result = books.filter((book) => favorites.includes(book.id));
    return result;
  }, [books, favorites, activeCategory, activeMode, query, sortBy, activeNav]);
  const myListings = useMemo(
    () => books.filter((book) => book.seller_user_id === user?.id),
    [books, user],
  );
  const pendingActivityCount = requests.filter((item) =>
    item.isSeller
      ? item.status === "Awaiting seller response"
      : !["Completed", "Declined", "Cancelled"].includes(item.status),
  ).length;

  function showToast(message) {
    setToast(message);
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => setToast(""), 2600);
  }

  async function toggleFavorite(id) {
    if (!user) {
      setModal({ type: "auth" });
      return;
    }
    try {
      const result = await apiPost("/api/favorites", { bookId: id });
      setFavorites((current) => result.favorite
        ? [...current, id]
        : current.filter((item) => item !== id));
    } catch {
      showToast("Could not save this book. Check that the database is running.");
    }
  }

  function openAction(book, kind) {
    if (kind !== "detail" && !user) {
      setModal({ type: "auth" });
      return;
    }
    setModal({ type: kind, book });
  }

  function openPublish() {
    setModal(user ? { type: "publish" } : { type: "auth" });
  }

  async function signOut() {
    const token = localStorage.getItem("paper-loop-token");
    try { await fetch("/api/auth/session", { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }); }
    finally {
      localStorage.removeItem("paper-loop-token");
      localStorage.removeItem("paper-loop-user");
      setUser(null);
      setFavorites([]);
      setRequests([]);
      setActiveNav("home");
      showToast("You are signed out.");
    }
  }

  async function completePurchase(book, details = {}) {
    try {
      const request = {
        type: "Purchase",
        bookId: book.id,
        title: book.title,
        seller: book.seller,
        ...details,
      };
      await apiPost("/api/transactions", request);
      await refreshData();
    } catch (error) {
      showToast(error.message || "Could not place the order.");
      return;
    }
    setModal(null);
    setActiveNav("messages");
    showToast("Order request sent. The seller will respond before payment.");
  }

  async function completeExchange(book, offeredImage) {
    try {
      const request = {
        type: "Exchange",
        bookId: book.id,
        title: book.title,
        offeredImage,
        fulfillment: "pickup",
        seller: book.seller,
      };
      await apiPost("/api/transactions", request);
      await refreshData();
    } catch (error) {
      showToast(error.message || "Could not send the exchange request.");
      return;
    }
    setModal(null);
    setActiveNav("messages");
    showToast("Exchange request sent to the seller.");
  }

  async function completeMessage(book, message, offerPrice) {
    if (!user) {
      setModal({ type: "auth" });
      return;
    }
    try {
      const request = {
        type: "Message",
        bookId: book.id,
        title: book.title,
        seller: book.seller,
        message,
        offerPrice: offerPrice ? Number(offerPrice) : null,
      };
      await apiPost("/api/transactions", request);
      await refreshData();
    } catch (error) {
      showToast(error.message || "Could not send your message.");
      return;
    }
    setModal(null);
    setActiveNav("messages");
    showToast("Message sent. Replies will appear here.");
  }

  async function updateTransaction(id, action, values = {}) {
    try {
      await apiPatch(`/api/transactions/${id}`, { action, ...values });
      await refreshData();
      const notices = {
        accept: "Request accepted.", decline: "Request declined.", pay: "Demo payment completed.",
        fulfill: "Handover details saved.", received: "Receipt confirmed. Transaction completed.",
        cancel: "Request cancelled.", details: "Delivery details saved.",
      };
      showToast(notices[action] || "Transaction updated.");
      setModal(null);
    } catch (error) {
      showToast(error.message || "Could not update this transaction.");
    }
  }

  async function sendTransactionMessage(id, body) {
    try {
      await apiPost("/api/messages", { transactionId: id, body });
      await refreshData();
    } catch (error) {
      showToast(error.message || "Could not send this message.");
    }
  }

  async function changeListingStatus(book, status) {
    try {
      await apiPatch(`/api/books/${book.id}`, { status });
      await refreshData();
      showToast(status === "paused" ? "Listing paused." : "Listing is live again.");
    } catch (error) { showToast(error.message || "Could not update the listing."); }
  }

  async function removeListing(book) {
    try {
      await apiDelete(`/api/books/${book.id}`);
      await refreshData();
      showToast("Listing removed.");
    } catch (error) { showToast(error.message || "Could not remove the listing."); }
  }

  async function publishBook(book) {
    const listingData = book;
    const listing = {
      ...listingData,
      likes: 0,
      seller: user?.displayName || "You",
      location: "Local pickup",
      condition: book.condition || "Very Good",
      color: book.color || "sage",
      mark: book.title.slice(0, 1),
    };
    try {
      const savedListing = await apiPost("/api/books", listing);
      setBooks((current) => [savedListing, ...current]);
    } catch (error) {
      showToast(error.message || "Could not publish this listing.");
      return;
    }
    setActiveNav("home");
    setActiveMode("all");
    setActiveCategory("All");
    setQuery("");
    setModal(null);
    showToast("Your book is now listed.");
  }

  async function editListing(id, book) {
    const listingData = book;
    try {
      await apiPatch(`/api/books/${id}`, {
        action: "edit",
        ...listingData,
        wantedBooks: [],
      });
      await refreshData();
      setModal(null);
      showToast("Listing updated.");
    } catch (error) { showToast(error.message || "Could not update the listing."); }
  }

  function changeNav(key) {
    if (key === "publish") {
      openPublish();
      return;
    }
    if (key === "categories") {
      setActiveNav("home");
      document
        .querySelector(".category-row")
        ?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    if ((key === "messages" || key === "profile") && !user) {
      setModal({ type: "auth" });
      return;
    }
    setActiveNav(key);
  }

  const pageTitle =
    activeNav === "profile"
      ? "My account"
      : activeNav === "messages"
        ? "Activity"
        : "A good book deserves another reader";
  const pageIntro =
    activeNav === "profile"
      ? "Manage your listings, saved books, and account."
      : activeNav === "messages"
        ? "Your orders, swaps, and messages."
        : "Give pre-loved books another chapter. Find a book to buy or swap.";

  return (
    <div className="app-shell">
      <header className="topbar">
        <a
          className="brand"
          href="#home"
          onClick={(event) => {
            event.preventDefault();
            setActiveNav("home");
          }}
        >
          <span className="brand-icon">
            <Icon name="book" size={22} />
          </span>
          <span>
            <strong>Paper Loop</strong>
            <small>Used Book Exchange</small>
          </span>
        </a>
        <div className="location-pill">
          <Icon name="pin" size={15} />
          <span>Local</span>
          <Icon name="chevron" size={13} />
        </div>
        <nav className="desktop-nav" aria-label="Main navigation">
          <button type="button" className={activeNav === "home" ? "active" : ""} onClick={() => setActiveNav("home")}>Discover</button>
          <button type="button" className={activeNav === "messages" ? "active" : ""} onClick={() => changeNav("messages")}>Activity{pendingActivityCount > 0 && <span className="desktop-badge">{pendingActivityCount}</span>}</button>
          <button type="button" className={activeNav === "profile" ? "active" : ""} onClick={() => changeNav("profile")}>My account</button>
          <button type="button" className="desktop-list-button" onClick={openPublish}><Icon name="plus" size={15} /> List a book</button>
        </nav>
        <button
          type="button"
          className="avatar-button auth-button"
          onClick={() => user ? setActiveNav("profile") : setModal({ type: "auth" })}
          aria-label={user ? "Account" : "Sign in or register"}
        >
          <span>{user ? user.displayName.slice(0, 1).toUpperCase() : "Sign in"}</span>
        </button>
      </header>

      <main>
        <section className="welcome-section">
          <div className="welcome-copy">
            <div className="eyebrow">
              <Icon name="sparkle" size={15} /> Give every book another chapter
            </div>
            <h1>{pageTitle}</h1>
            <p>{pageIntro}</p>
          </div>
          <div className="welcome-art" aria-hidden="true">
            <div className="art-orbit orbit-one" />
            <div className="art-orbit orbit-two" />
            <div className="art-book book-back">
              <span>A world on every page</span>
            </div>
            <div className="art-book book-front">
              <span>
                Good
                <br />
                Again
              </span>
            </div>
            <span className="art-star">✳</span>
            <span className="art-dot" />
          </div>
        </section>

        <section className="search-section" aria-label="Search books">
          <Icon name="search" size={20} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search title, author, or ISBN"
            inputMode="search"
            onKeyDown={(event) => event.key === "Enter" && event.currentTarget.blur()}
          />
          {query && (
            <button
              type="button"
              className="clear-search"
              onClick={() => setQuery("")}
              aria-label="Clear search"
            >
              <Icon name="close" size={16} />
            </button>
          )}
          <button
            type="button"
            className="search-submit"
            onClick={() => document.activeElement.blur()}
          >
            Search
          </button>
        </section>

        {activeNav === "home" && (
          <section className="market-intro">
            <div className="market-heading">
              <div>
                <span className="section-kicker">COMMUNITY PICKS</span>
                <h2>Find your next read</h2>
              </div>
              <div className="local-note">
                <span className="online-dot" /> Nearby listings
              </div>
            </div>
            <div className="market-promise">
              <div className="promise-item">
                <span className="promise-icon">
                  <Icon name="swap" size={17} />
                </span>
                <span>
                  <b>Book swap</b>
                  <small>Trade a book you own</small>
                </span>
              </div>
              <span className="promise-divider" />
              <div className="promise-item">
                <span className="promise-icon promise-icon-peach">¥</span>
                <span>
                  <b>Buy a book</b>
                  <small>Good books for less</small>
                </span>
              </div>
            </div>
          </section>
        )}

        <section className={`browse-section browse-${activeNav}`}>
          <div className="browse-toolbar">
            <div className="mode-switch" role="tablist" aria-label="Trade options">
              {[
                ["all", "All books"],
                ["exchange", "Book swap"],
                ["sale", "Buy a book"],
              ].map(([value, label]) => (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeMode === value}
                  className={activeMode === value ? "selected" : ""}
                  key={value}
                  onClick={() => {
                    setActiveMode(value);
                    setActiveNav("home");
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
            <label className="sort-select">
              <span className="sr-only">Sort</span>
              <select
                value={sortBy}
                onChange={(event) => setSortBy(event.target.value)}
              >
                <option>Recommended</option>
                <option>Newest</option>
                <option>Price: Low to High</option>
              </select>
              <Icon name="chevron" size={13} />
            </label>
          </div>

          <div className="category-row">
            {categories.map((category) => (
              <button
                type="button"
                key={category}
                className={`category-chip${activeCategory === category ? " active" : ""}`}
                onClick={() => {
                  setActiveCategory(category);
                  setActiveNav("home");
                }}
              >
                {category}
              </button>
            ))}
          </div>

          {activeNav === "messages" ? (
            <ActivityPanel
              transactions={requests}
              user={user}
              onBrowse={() => setActiveNav("home")}
              onAction={updateTransaction}
              onMessage={sendTransactionMessage}
              onDeliveryDetails={(transaction) => setModal({ type: "delivery-details", transaction })}
            />
          ) : activeNav === "profile" ? (
            <section className="profile-summary">
              <div className="profile-card">
                <div className="profile-avatar">{user?.displayName?.slice(0, 1).toUpperCase() || "G"}</div>
                <div>
                  <b>{user?.displayName || "Guest"}</b>
                  <p>Keep good books in circulation</p>
                </div>
                <button
                  type="button"
                  onClick={openPublish}
                >
                  <Icon name="plus" size={16} />
                  List a book
                </button>
                {user && <button type="button" className="signout-button" onClick={signOut}>Sign out</button>}
              </div>
              <div className="profile-stats">
                <div>
                  <b>{books.filter((book) => book.seller_user_id === user?.id).length}</b>
                  <span>My listings</span>
                </div>
                <div>
                  <b>{favorites.length}</b>
                  <span>Saved</span>
                </div>
                <div>
                  <b>{requests.length}</b>
                  <span>Activity</span>
                </div>
              </div>
              <div className="profile-note">
                <Icon name="shield" size={18} />
                <span>
                  <b>Trade with confidence</b>
                  <small>Arrange local pickup or shipping with the seller.</small>
                </span>
                <Icon name="chevron" size={16} />
              </div>
              <div className="account-section-heading">
                <div><h2>My listings</h2><p>Manage availability and see the requests buyers have sent.</p></div>
                <button type="button" className="text-link" onClick={openPublish}>Add a book <Icon name="plus" size={15} /></button>
              </div>
              {myListings.length ? <div className="my-listing-list">
                {myListings.map((book) => <article className="my-listing-row" key={book.id}>
                  <BookCover book={book} compact />
                  <div className="my-listing-copy"><b>{book.title}</b><span>{book.author}</span>
                    <small>ISBN {book.barcode} · {book.status === "active" ? "Live" : book.status}</small></div>
                  <div className="my-listing-actions">
                    {book.status !== "sold" && <button type="button" onClick={() => setModal({ type: "edit", book })}>Edit</button>}
                    {book.status !== "sold" && <button type="button" onClick={() => changeListingStatus(book, book.status === "paused" ? "active" : "paused")}>{book.status === "paused" ? "Relist" : "Pause"}</button>}
                    {book.status !== "sold" && <button type="button" className="danger-text" onClick={() => removeListing(book)}>Remove</button>}
                  </div>
                </article>)}
              </div> : <div className="empty-inline">You have not listed a book yet.</div>}
              <div className="account-section-heading"><div><h2>Saved books</h2><p>Books you have bookmarked.</p></div></div>
              {visibleBooks.length ? <div className="book-grid">
                {visibleBooks.map((book) => <BookCard key={book.id} book={book} favorite isOwner={book.seller_user_id === user?.id} onFavorite={toggleFavorite} onAction={openAction} />)}
              </div> : <div className="empty-inline">No saved books yet. Tap the heart on a book to keep it here.</div>}
            </section>
          ) : (
            <>
              <div className="results-heading">
                <div>
                  <h2>
                    {activeNav === "home" ? "Books for you" : "Saved books"}
                    <span>{visibleBooks.length}</span>
                  </h2>
                  <p>
                    {activeMode === "exchange"
                      ? "Sellers review a photo of the book you offer."
                      : activeMode === "sale"
                        ? "Find your next read for less."
                        : "Every pre-loved book can find a new reader."}
                  </p>
                </div>
                <button
                  type="button"
                  className="text-link"
                  onClick={() => setActiveCategory("All")}
                >
                  View all <Icon name="arrow" size={15} />
                </button>
              </div>
              {visibleBooks.length ? (
                <div className="book-grid">
                  {visibleBooks.map((book) => (
                    <BookCard
                      key={book.id}
                      book={book}
                      isOwner={book.seller_user_id === user?.id}
                      favorite={favorites.includes(book.id)}
                      onFavorite={toggleFavorite}
                      onAction={openAction}
                    />
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <span className="empty-icon">
                    <Icon
                      name={activeNav === "profile" ? "heart" : "book"}
                      size={28}
                    />
                  </span>
                  <h3>
                    {activeNav === "profile"
                      ? "No saved books yet"
                      : "No books found"}
                  </h3>
                  <p>
                    {activeNav === "profile"
                      ? "Tap the heart on a book to save it here."
                      : "Try another keyword or category."}
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setQuery("");
                      setActiveCategory("All");
                      setActiveNav("home");
                    }}
                  >
                    Keep browsing
                  </button>
                </div>
              )}
            </>
          )}
        </section>

        <section className="closing-banner">
          <div className="closing-mark">
            <Icon name="book" size={22} />
          </div>
          <div>
            <span>Give a pre-loved book a new story</span>
            <p>List a book and pass it on.</p>
          </div>
          <button type="button" onClick={openPublish}>
            List my book <Icon name="arrow" size={16} />
          </button>
        </section>
      </main>

      <nav className="bottom-nav" aria-label="Main navigation">
        {navItems.map(([key, label, icon]) => (
          <button
            type="button"
            key={key}
            className={`${activeNav === key || (key === "categories" && activeCategory !== "All") ? "active" : ""}${key === "publish" ? " nav-publish" : ""}`}
            onClick={() => changeNav(key)}
          >
            <span className="nav-icon">
              <Icon name={icon} size={key === "publish" ? 21 : 19} />
            </span>
            <span>{label}</span>
            {key === "messages" && pendingActivityCount > 0 && <span className="mobile-badge">{pendingActivityCount}</span>}
          </button>
        ))}
      </nav>

      {toast && (
        <div className="toast">
          <span>
            <Icon name="check" size={16} />
          </span>
          {toast}
        </div>
      )}

      {modal?.type === "buy" && (
        <CheckoutModal
          book={modal.book}
          onClose={() => setModal(null)}
          onSubmit={(details) => completePurchase(modal.book, details)}
        />
      )}

      {modal?.type === "detail" && (
        <BookDetailModal
          book={modal.book}
          isOwner={modal.book.seller_user_id === user?.id}
          onClose={() => setModal(null)}
          onMessage={completeMessage}
          onAction={openAction}
        />
      )}

      {modal?.type === "exchange" && (
        <Modal
          title="Request a swap"
          subtitle="Upload a photo of the book you want to exchange. The seller will review it."
          onClose={() => setModal(null)}
        >
          <div className="exchange-target">
            <BookCover book={modal.book} compact />
            <div>
              <small>Book listed</small>
              <b>{modal.book.title}</b>
              <span>The seller will review the book photo before accepting.</span>
            </div>
          </div>
          <ExchangeOffer
            onSubmit={(photo) => completeExchange(modal.book, photo)}
          />
        </Modal>
      )}

      {modal?.type === "publish" && (
        <PublishModal onClose={() => setModal(null)} onSubmit={publishBook} />
      )}
      {modal?.type === "edit" && (
        <PublishModal initialBook={modal.book} onClose={() => setModal(null)} onSubmit={(book) => editListing(modal.book.id, book)} />
      )}

      {modal?.type === "auth" && (
        <AuthModal
          onClose={() => setModal(null)}
          onSuccess={(result) => {
            localStorage.setItem("paper-loop-token", result.token);
            localStorage.setItem("paper-loop-user", JSON.stringify(result.user));
            window.location.reload();
          }}
        />
      )}
      {modal?.type === "delivery-details" && (
        <CheckoutModal
          transaction={modal.transaction}
          onClose={() => setModal(null)}
          onSubmit={(details) => updateTransaction(modal.transaction.id, "details", details)}
        />
      )}
    </div>
  );
}

function CheckoutModal({ book, transaction, onClose, onSubmit }) {
  const [fulfillment, setFulfillment] = useState(transaction?.fulfillment || "shipping");
  const [recipientName, setRecipientName] = useState(transaction?.recipientName || "");
  const [phone, setPhone] = useState(transaction?.phone || "");
  const [address, setAddress] = useState(transaction?.address || "");
  const [error, setError] = useState("");
  function submit(event) {
    event.preventDefault();
    if (!recipientName.trim() || !phone.trim() || (fulfillment === "shipping" && !address.trim())) {
      setError("Enter the recipient name, phone number, and shipping address.");
      return;
    }
    onSubmit({ fulfillment, recipientName: recipientName.trim(), phone: phone.trim(), address: address.trim() });
  }
  return <Modal
    title={transaction ? "Delivery details" : "Request to buy"}
    subtitle={transaction ? "Add where the seller should send the book." : "The seller confirms availability before you make the simulated payment."}
    onClose={onClose}
    className="checkout-modal"
  >
    {book && <div className="order-book">
      <BookCover book={book} compact />
      <div><b>{book.title}</b><span>{book.author}</span><small>{book.condition} · Seller: {book.seller}</small></div>
      <strong>¥{book.price}</strong>
    </div>}
    <form className="publish-form checkout-form" onSubmit={submit}>
      <label>Delivery method
        <select value={fulfillment} onChange={(event) => setFulfillment(event.target.value)}>
          <option value="shipping">Ship to an address</option>
          <option value="pickup">Arrange local pickup</option>
        </select>
      </label>
      <label>Recipient name<input required autoComplete="name" value={recipientName} onChange={(event) => setRecipientName(event.target.value)} /></label>
      <label>Phone number<input required type="tel" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} /></label>
      {fulfillment === "shipping" && <label>Shipping address<textarea required autoComplete="street-address" rows="3" value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Street, city, region, postal code" /></label>}
      {error && <p className="form-error">{error}</p>}
      <button type="submit" className="primary-wide">{transaction ? "Save delivery details" : "Send order request"}{book && !transaction ? ` · ¥${book.price}` : ""}</button>
      {!transaction && <p className="checkout-note"><Icon name="shield" size={16} /> No payment is taken until the seller accepts. Payment is simulated.</p>}
    </form>
  </Modal>;
}

function ActivityPanel({ transactions, user, onBrowse, onAction, onMessage, onDeliveryDetails }) {
  if (!transactions.length) return <div className="empty-state activity-empty">
    <span className="empty-icon"><Icon name="chat" size={28} /></span>
    <h3>No orders or conversations yet</h3><p>Purchase and exchange requests, seller responses, and messages will appear here.</p>
    <button type="button" onClick={onBrowse}>Browse books</button>
  </div>;
  return <section className="messages-view transaction-list">
    <div className="activity-intro"><b>Buying and selling</b><span>Requests and conversations are shared with the other participant.</span></div>
    {transactions.map((transaction) => <TransactionCard key={transaction.id} transaction={transaction} user={user} onAction={onAction} onMessage={onMessage} onDeliveryDetails={onDeliveryDetails} />)}
  </section>;
}

function TransactionCard({ transaction, user, onAction, onMessage, onDeliveryDetails }) {
  const [message, setMessage] = useState("");
  const [showFulfillment, setShowFulfillment] = useState(false);
  const [trackingCompany, setTrackingCompany] = useState("");
  const [trackingNumber, setTrackingNumber] = useState("");
  const isSeller = transaction.isSeller;
  const peer = isSeller ? transaction.buyerName : transaction.sellerName || transaction.seller;
  const amount = transaction.offerPrice || transaction.price;
  const terminal = ["Completed", "Declined", "Cancelled"].includes(transaction.status);
  function submitMessage(event) {
    event.preventDefault();
    if (!message.trim()) return;
    onMessage(transaction.id, message.trim());
    setMessage("");
  }
  return <article className="transaction-card">
    <div className="transaction-head">
      <span className={`request-symbol ${transaction.type === "Exchange" ? "symbol-swap" : "symbol-buy"}`}><Icon name={transaction.type === "Exchange" ? "swap" : transaction.type === "Message" ? "chat" : "book"} /></span>
      <div className="transaction-title"><b>{transaction.type === "Message" ? "Offer / message" : transaction.type} · {transaction.title}</b><span>{isSeller ? "Selling to" : "Buying from"} {peer || "former member"}</span></div>
      <span className={`transaction-status${terminal ? " status-muted" : ""}`}>{transaction.status}</span>
    </div>
    <div className="transaction-details">
      {transaction.offerPrice && <p><b>Offer:</b> ¥{transaction.offerPrice}{transaction.price ? ` (listed at ¥${transaction.price})` : ""}</p>}
      {transaction.type === "Purchase" && transaction.recipientName && <p><b>{transaction.fulfillment === "pickup" ? "Pickup contact" : "Ship to"}:</b> {transaction.recipientName} · {transaction.phone}{transaction.fulfillment === "shipping" ? ` · ${transaction.address}` : " · Local pickup"}</p>}
      {transaction.trackingNumber && <p><b>Tracking:</b> {transaction.trackingCompany} {transaction.trackingNumber}</p>}
      {transaction.status === "Awaiting seller response" && <p>The seller should review the request and respond here.</p>}
      {transaction.status === "Awaiting payment" && <p>Seller accepted. Confirm the order to complete the simulated payment of ¥{amount}.</p>}
      {transaction.type === "Exchange" && <p>Coordinate the book handover in this conversation. Local collection is selected for this request.</p>}
    </div>
    {transaction.type === "Exchange" && transaction.offeredImage && <figure className="exchange-review-photo">
      <figcaption>Photo of the book offered for exchange</figcaption>
      <img src={transaction.offeredImage} alt="Book offered for exchange" />
    </figure>}
    {!!transaction.messages?.length && <div className="conversation-log">
      {transaction.messages.map((item) => <div className={`chat-message${item.senderId === user?.id ? " own-message" : ""}`} key={item.id}><b>{item.senderId === user?.id ? "You" : item.sender}</b><span>{item.body}</span><time>{item.createdAt}</time></div>)}
    </div>}
    {!terminal && <form className="reply-form" onSubmit={submitMessage}><input value={message} maxLength="2000" onChange={(event) => setMessage(event.target.value)} placeholder="Message the other person" aria-label="Message the other person" /><button type="submit" disabled={!message.trim()}><Icon name="send" size={15} /> Send</button></form>}
    <div className="transaction-actions">
      {isSeller && transaction.status === "Awaiting seller response" && <>
        <button type="button" className="primary-small" onClick={() => onAction(transaction.id, "accept")}>{transaction.type === "Message" && transaction.offerPrice ? "Accept offer" : "Accept request"}</button>
        <button type="button" className="secondary-small" onClick={() => onAction(transaction.id, "decline")}>Decline</button>
      </>}
      {!isSeller && ["Awaiting seller response", "Awaiting delivery details", "Awaiting payment", "Paid · preparing shipment", "Accepted · arrange exchange"].includes(transaction.status) && <button type="button" className="secondary-small" onClick={() => onAction(transaction.id, "cancel")}>Cancel request</button>}
      {!isSeller && transaction.status === "Awaiting delivery details" && <button type="button" className="primary-small" onClick={() => onDeliveryDetails(transaction)}>Add delivery details</button>}
      {!isSeller && transaction.status === "Awaiting payment" && <button type="button" className="primary-small" onClick={() => onAction(transaction.id, "pay")}>Pay ¥{amount} · demo</button>}
      {isSeller && ["Paid · preparing shipment", "Accepted · arrange exchange"].includes(transaction.status) && <button type="button" className="primary-small" onClick={() => setShowFulfillment((open) => !open)}>{transaction.fulfillment === "pickup" ? "Mark ready for collection" : "Add tracking / mark shipped"}</button>}
      {!isSeller && ["Shipped", "Ready for collection"].includes(transaction.status) && <button type="button" className="primary-small" onClick={() => onAction(transaction.id, "received")}>Confirm received</button>}
    </div>
    {showFulfillment && <form className="fulfillment-form" onSubmit={(event) => { event.preventDefault(); onAction(transaction.id, "fulfill", { trackingCompany, trackingNumber }); setShowFulfillment(false); }}>
      {transaction.fulfillment === "shipping" ? <><label>Courier<input required value={trackingCompany} onChange={(event) => setTrackingCompany(event.target.value)} placeholder="Courier company" /></label><label>Tracking number<input required value={trackingNumber} onChange={(event) => setTrackingNumber(event.target.value)} placeholder="Tracking number" /></label></> : <p>Confirm the book is ready for local collection. Coordinate the time and place in the conversation.</p>}
      <button type="submit" className="primary-small">Save handover update</button>
    </form>}
  </article>;
}

function PublishModal({ initialBook, onClose, onSubmit }) {
  const [form, setForm] = useState(() => ({
    title: initialBook?.title || "",
    author: initialBook?.author || "",
    barcode: initialBook?.barcode || "",
    category: initialBook?.category || "Fiction",
    price: initialBook ? String(initialBook.price || "") : "",
    mode: initialBook?.mode || "both",
    condition: initialBook?.condition || "Very Good",
    image: initialBook?.image || "",
  }));
  const [error, setError] = useState("");

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function selectPhoto(file) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Choose an image file for the book photo.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const photo = new Image();
      photo.onload = () => {
        const scale = Math.min(1, 1200 / Math.max(photo.width, photo.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(photo.width * scale);
        canvas.height = Math.round(photo.height * scale);
        canvas.getContext("2d").drawImage(photo, 0, 0, canvas.width, canvas.height);
        update("image", canvas.toDataURL("image/jpeg", 0.78));
        setError("");
      };
      photo.onerror = () => setError("This image could not be opened.");
      photo.src = reader.result;
    };
    reader.onerror = () => setError("This image could not be read.");
    reader.readAsDataURL(file);
  }

  function submit(event) {
    event.preventDefault();
    if (!form.title.trim() || !form.author.trim() || !form.barcode.trim()) {
      setError("Enter the title, author, and ISBN barcode.");
      return;
    }
    const barcode = form.barcode.replace(/\D/g, "");
    if (![10, 13].includes(barcode.length)) {
      setError("Enter a 10 or 13 digit ISBN barcode.");
      return;
    }
    if (form.mode !== "exchange" && (!form.price || Number(form.price) < 1)) {
      setError("Enter a price of at least ¥1.");
      return;
    }
    onSubmit({
      ...form,
      barcode,
      price: Number(form.price) || 0,
      wantedBooks: [],
      category: form.category,
      color: ["sage", "coral", "ochre", "blue", "lavender"][
        Math.floor(Math.random() * 5)
      ],
    });
  }

  return (
    <Modal
      title={initialBook ? "Edit listing" : "List a book"}
      subtitle={initialBook ? "Update the details buyers see." : "Find a new reader for a book you no longer need."}
      onClose={onClose}
      className="publish-modal"
    >
      <form className="publish-form" onSubmit={submit}>
        <label>
          Title
          <input
            value={form.title}
            onChange={(event) => update("title", event.target.value)}
            placeholder="e.g. The Little Prince"
            autoFocus
          />
        </label>
        <label>
          Author
          <input
            value={form.author}
            onChange={(event) => update("author", event.target.value)}
            placeholder="Enter the author"
          />
        </label>
        <label>
          ISBN barcode
          <input
            value={form.barcode}
            onChange={(event) => update("barcode", event.target.value)}
            placeholder="Scan or enter the 10 or 13 digit ISBN"
            inputMode="numeric"
            autoComplete="off"
          />
        </label>
        <label>
          Book photo <span className="optional-label">optional</span>
          <input type="file" accept="image/*" capture="environment" onChange={(event) => selectPhoto(event.target.files?.[0])} />
          <small className="field-hint">Add a clear photo of the actual book, including any visible wear.</small>
        </label>
        {form.image && <div className="photo-preview"><img src={form.image} alt="Book listing preview" /><button type="button" onClick={() => update("image", "")}>Remove photo</button></div>}
        <div className="form-row">
          <label>
            Category
            <select
              value={form.category}
              onChange={(event) => update("category", event.target.value)}
            >
              {categories
                .filter((item) => item !== "All")
                .map((item) => (
                  <option key={item}>{item}</option>
                ))}
            </select>
          </label>
          <label>
            Book condition
            <select
              value={form.condition}
              onChange={(event) => update("condition", event.target.value)}
            >
              <option>Like New</option>
              <option>Excellent</option>
              <option>Very Good</option>
              <option>Good</option>
            </select>
          </label>
        </div>
        <fieldset>
          <legend>Trade options</legend>
          <div className="trade-mode-options">
            {[
              ["both", "Swap / sell"],
              ["exchange", "Swap only"],
              ["sale", "Sell only"],
            ].map(([value, label]) => (
              <label
                className={form.mode === value ? "chosen" : ""}
                key={value}
              >
                <input
                  type="radio"
                  name="tradeMode"
                  checked={form.mode === value}
                  onChange={() => update("mode", value)}
                />
                {label}
              </label>
            ))}
          </div>
        </fieldset>
        {form.mode !== "exchange" && (
          <label>
            Price (CNY)
            <div className="price-input">
              <span>¥</span>
              <input
                type="number"
                min="1"
                value={form.price}
                onChange={(event) => update("price", event.target.value)}
                placeholder="Enter price"
              />
            </div>
          </label>
        )}
        {error && <p className="form-error">{error}</p>}
        <button type="submit" className="primary-wide">
          {initialBook ? "Save changes" : "Publish listing"} <Icon name="arrow" size={17} />
        </button>
      </form>
    </Modal>
  );
}

function ExchangeOffer({ onSubmit }) {
  const [photo, setPhoto] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function selectPhoto(file) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Choose an image file showing the book you are offering.");
      return;
    }
    setBusy(true);
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, 1200 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(image.width * scale);
        canvas.height = Math.round(image.height * scale);
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        const compressed = canvas.toDataURL("image/jpeg", 0.76);
        if (compressed.length > 1_400_000) setError("This image is too large. Choose a smaller photo.");
        else { setPhoto(compressed); setError(""); }
        setBusy(false);
      };
      image.onerror = () => { setError("This image could not be opened."); setBusy(false); };
      image.src = reader.result;
    };
    reader.onerror = () => { setError("This image could not be read."); setBusy(false); };
    reader.readAsDataURL(file);
  }

  return <div className="exchange-photo-flow">
    <label className="exchange-photo-label">
      Photo of the book you are offering
      <input type="file" accept="image/*" capture="environment" onChange={(event) => selectPhoto(event.target.files?.[0])} />
      <small>Take or choose a clear photo. The seller will check the book’s condition before accepting.</small>
    </label>
    {photo && <div className="exchange-photo-preview"><img src={photo} alt="Book offered for exchange" /><button type="button" onClick={() => setPhoto("")}>Change photo</button></div>}
    {error && <p className="form-error">{error}</p>}
    <button type="button" className="primary-wide" disabled={!photo || busy} onClick={() => onSubmit(photo)}>
      <Icon name="swap" size={17} /> {busy ? "Preparing photo…" : "Send exchange request"}
    </button>
  </div>;
}

function BookDetailModal({ book, isOwner, onClose, onMessage, onAction }) {
  const [message, setMessage] = useState("");
  const [offerPrice, setOfferPrice] = useState("");
  const [error, setError] = useState("");
  const canExchange = !isOwner && book.mode !== "sale";
  const canBuy = !isOwner && book.mode !== "exchange";

  function submitMessage(event) {
    event.preventDefault();
    if (!message.trim() && !offerPrice) {
      setError("Enter a message or offer price before sending.");
      return;
    }
    if (offerPrice && Number(offerPrice) <= 0) {
      setError("Your offer must be greater than ¥0.");
      return;
    }
    onMessage(book, message.trim(), offerPrice);
  }

  return (
    <Modal
      title="Book details"
      subtitle="Review the terms or message the seller."
      onClose={onClose}
      className="detail-modal"
    >
      <div className="detail-book-head">
        <BookCover book={book} compact />
        <div className="detail-book-copy">
          <span className="detail-category">
            {book.category} · {book.condition}
          </span>
          <h3>{book.title}</h3>
          <p>{book.author}</p>
          <small>
            {book.seller} · {book.location}
          </small>
          {book.barcode && <small className="detail-isbn">ISBN {book.barcode}</small>}
        </div>
      </div>

      <div className="listing-terms">
        {canBuy && (
          <div className="listing-price-term">
            <span>Asking price</span>
            <strong>¥{book.price}</strong>
          </div>
        )}
        {canExchange && (
          <div className="listing-exchange-term">
            <div>
              <b>One-to-one book swap</b>
              <span>Upload a photo and let the seller review the condition.</span>
            </div>
          </div>
        )}
      </div>

      {!isOwner && <form className="message-form" onSubmit={submitMessage}>
        <label>
          Message the seller
          <textarea
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            placeholder="Ask about condition, delivery, or share your offer."
            rows="3"
          />
        </label>
        {canBuy && (
          <label>
            Your offer price (optional)
            <div className="price-input">
              <span>¥</span>
              <input
                type="number"
                min="1"
                value={offerPrice}
                onChange={(event) => setOfferPrice(event.target.value)}
                placeholder={`Asking price ¥${book.price}`}
              />
            </div>
          </label>
        )}
        {error && <p className="form-error">{error}</p>}
        <button type="submit" className="message-submit">
          <Icon name="send" size={15} />
          Send message / offer
        </button>
      </form>}

      <div className="detail-action-row">
        {canExchange && (
          <button
            type="button"
            className="detail-exchange-button"
            onClick={() => onAction(book, "exchange")}
          >
            <Icon name="swap" size={16} />
            Offer a book for exchange
          </button>
        )}
        {canBuy && (
          <button
            type="button"
            className="detail-buy-button"
            onClick={() => onAction(book, "buy")}
          >
            Buy at asking price · ¥{book.price}
          </button>
        )}
      </div>
    </Modal>
  );
}

function AuthModal({ onClose, onSuccess }) {
  const [mode, setMode] = useState("login");
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const result = await apiPost(`/api/auth/${mode === "register" ? "register" : "login"}`, {
        displayName,
        email,
        password,
      });
      onSuccess(result);
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      title={mode === "register" ? "Create your account" : "Welcome back"}
      subtitle={mode === "register" ? "Join the community and pass a book on." : "Sign in to save books and trade."}
      onClose={onClose}
      className="auth-modal"
    >
      <div className="auth-tabs">
        <button type="button" className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); setError(""); }}>Sign in</button>
        <button type="button" className={mode === "register" ? "active" : ""} onClick={() => { setMode("register"); setError(""); }}>Create account</button>
      </div>
      <form className="publish-form auth-form" onSubmit={submit}>
        {mode === "login" && <div className="demo-access"><b>Try the sample seller account</b><span>demo@paperloop.local</span><code>PaperLoop2026!</code></div>}
        {mode === "register" && (
          <label>
            Display name
            <input value={displayName} onChange={(event) => setDisplayName(event.target.value)} minLength="2" maxLength="40" autoComplete="name" required />
          </label>
        )}
        <label>
          Email
          <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" required />
        </label>
        <label>
          Password
          <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} minLength="8" autoComplete={mode === "register" ? "new-password" : "current-password"} required />
          {mode === "register" && <small className="field-hint">Use at least 8 characters.</small>}
        </label>
        {error && <p className="form-error">{error}</p>}
        <button type="submit" className="primary-wide" disabled={busy}>
          {busy ? "Please wait…" : mode === "register" ? "Create account" : "Sign in"}
          {!busy && <Icon name="arrow" size={17} />}
        </button>
      </form>
    </Modal>
  );
}

export default App;

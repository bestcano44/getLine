@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is missing. Install Node.js 20.19+ or 22.12+ and try again.
  goto finish
)

where npm >nul 2>nul
if errorlevel 1 (
  echo npm is missing. Reinstall Node.js with npm included, then try again.
  goto finish
)

if not exist "node_modules\vite\bin\vite.js" (
  echo Installing project dependencies...
  call npm install
  if errorlevel 1 goto finish
)

call npm run dev

:finish
echo.
pause

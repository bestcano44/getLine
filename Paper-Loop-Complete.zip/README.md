# Paper Loop — Used Book Exchange

Paper Loop is a mobile-first marketplace for second-hand books. Members can list, buy, and exchange books, contact one another, and follow a transaction through handover. The payment step is simulated; the rest of the listing, messaging, order, and inventory workflow is stored in SQLite.

## What members can do

- Create an account, sign in, and sign out. Passwords are stored as salted PBKDF2 hashes.
- Browse active listings, filter by category and trade method, sort by price or date, and search by title, author, or ISBN barcode.
- Save listings to a personal account.
- Publish a book with its ISBN, condition, price, trade method, and an optional photo of the actual copy.
- Edit, pause, relist, or remove a personal listing. A listing with an open transaction cannot be removed or paused.
- Ask to buy at the asking price, send an offer, or request an exchange by uploading a photo of the book they propose to trade. Sellers review the photo and decide whether to accept.
- Continue a private conversation on the transaction. The Activity area shows requests for both the buyer and seller and refreshes while it is open.
- Open Activity from either the desktop header or the mobile bottom bar. A badge shows open activity, and a signed-in page refreshes transaction data in the background and raises an in-app toast for new seller requests or messages.
- Accept or decline requests as the seller. Buyers can cancel before handover.
- For purchases, provide shipping or local-pickup details, complete a simulated payment after acceptance, and follow manually entered courier tracking or collection status.
- For exchanges, reserve the seller's listing after acceptance, coordinate local handover in the transaction conversation, and confirm receipt to complete the exchange.
- Confirm receipt to complete a transaction and update listing availability.

## Run locally

Paper Loop runs in current desktop and mobile browsers on Windows, macOS, and Linux. To run the project locally, install Node.js 20.19+ (or 22.12+) with npm, and Python 3.

On Windows, double-click `start-windows.bat`. On macOS, double-click `start-mac.command` (if macOS blocks it, Control-click the file and choose **Open**). Each launcher installs the frontend dependencies the first time, then starts the website and database service together. On Linux, or if you prefer a terminal, run these commands from the project folder:

```sh
npm install
```

Install dependencies once, then start the React site and SQLite API together:

```sh
npm run dev
```

Open the local address printed by Vite, usually `http://127.0.0.1:5173`. If that port is in use, Vite prints another address. Press `Ctrl+C` to stop the app. The same `npm install` and `npm run dev` commands work in PowerShell, Command Prompt, macOS Terminal, and Linux terminals.

Create a normal account for day-to-day use. A local sample seller account is also seeded so the whole request flow can be tried with a second account:

- Email: `demo@paperloop.local`
- Password: `PaperLoop2026!`

For example, register as a buyer in one browser and sign in as the sample seller in another browser to handle requests from both sides. The sample account is for local coursework demonstrations only; change or remove it before deploying the app beyond a private development environment.

## Data and limits

The database is created at `data/book_exchange.sqlite3`. Accounts, listings, saved books, transactions, and transaction messages persist across restarts. The service listens on localhost and is intended to run locally for a course project.

The payment action records a simulated payment only. It does not charge a card or move money. Sellers enter the courier and tracking number themselves; no courier label or delivery booking is purchased. Email verification, password recovery, SMS, external payment, and production hosting are not configured.

## Main files

- `src/App.js` — screens and marketplace workflows
- `src/styles.css` — responsive mobile and desktop layout
- `src/data.js` — starter book listings
- `server.py` — authentication, listing, message, transaction, and SQLite API
- `vite.config.js` — local API proxy

#!/bin/bash
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Install Node.js 20.19+ or 22.12+ (including npm), then open this file again."
  read -r -p "Press Return to close..."
  exit 1
fi

if [ ! -f "node_modules/vite/bin/vite.js" ]; then
  echo "Installing project dependencies..."
  npm install || { read -r -p "Press Return to close..."; exit 1; }
fi

npm run dev
read -r -p "Press Return to close..."
